from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import data

# Create your views here.

def dashboard(request):
    return render(request,'dashboard.html')

def home(request):
    return render(request,"home.html")

def about(request):
    return render(request,"about.html")

def case(request):
    return render(request,"case.html")

def skills(request):
    return render(request,"skills.html")


def contact(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        email = request.POST.get('email')
        message = request.POST.get('message')

        

        # Save data only if POST
        obj = data()
        obj.fname = fname
        obj.email = email
        obj.message = message
        obj.save()

        return render(request, "contact.html", {"success": True})

    # For GET request, just render the form   
    return render(request, "contact.html")


# def contact(request):
#     if request.method == "POST":
#         fname = request.POST.get("fname", "").strip()
#         email = request.POST.get("email", "").strip()

#         # clear old errors and validate
#         if not fname and not email:
#             messages.error(request, "⚠️ Full Name and Email are required.")
#         elif not fname:
#             messages.error(request, "⚠️ Full Name is required.")
#         elif not email:
#             messages.error(request, "⚠️ Email is required.")
#         else:
#             # ✅ Save data if valid
#             obj = data(fname=fname, email=email)
#             obj.save()
#             messages.success(request, "✅ Your message has been submitted successfully!")
#             return redirect("contact") 

#     return render(request, "contact.html")
