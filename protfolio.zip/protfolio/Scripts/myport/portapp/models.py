from django.db import models

# Create your models here.

class data(models.Model):
    fname=models.CharField(max_length=50,default="")
    email=models.CharField(max_length=50,default="")
    message=models.CharField(max_length=50,default="")